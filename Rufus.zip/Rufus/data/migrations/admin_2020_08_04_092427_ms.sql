ALTER TABLE goadmin_menu
ADD plugin_name varchar(150) NOT NULL DEFAULT '',
ADD uuid varchar(150) NOT NULL DEFAULT '';