package postgres

import _ "github.com/lib/pq" // Import the postgresql driver.
